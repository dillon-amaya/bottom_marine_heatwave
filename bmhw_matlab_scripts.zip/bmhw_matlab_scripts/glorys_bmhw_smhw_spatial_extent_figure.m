function [ax] = glorys_bmhw_smhw_spatial_extent_figure(bhw_frac,bhw_int_time,bhw_diff_time,shw_frac,shw_int_time,f,N)

lme_ID={'East Bering Sea'; 'Gulf of Alaska'; 'California Current'; 'Gulf of California';...
    'Gulf of Mexico'; 'Southeast US (SEUS)'; 'Northeast US (NEUS)'; 'Scotian';...
    'Labrador'};

big_shw=sum(shw_frac>0.5,2);
big_bhw=sum(bhw_frac>0.5,2);

if N==1 %BMHW spatial extent
    X=bhw_frac;
    Y=bhw_int_time;
    
    cmin=0;
    cmax=5;
    intv=(cmax-cmin)./10;
    yl=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    pu=brewermap(numel(cmin:intv:cmax)-1,'Purples');
    cm=customcolormap([0 0.5 1],[pu(end,:); default_colors('or'); yl(2,:)],numel(cmin:intv:cmax)-1);
    cID='Intensity (\circC)';
    
elseif N==2 %BMHW Intensity
    X=shw_frac;
    Y=shw_int_time;
    
    cmin=0;
    cmax=5;
    intv=(cmax-cmin)./10;
    yl=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    pu=brewermap(numel(cmin:intv:cmax)-1,'Purples');
    cm=customcolormap([0 0.5 1],[pu(end,:); default_colors('or'); yl(2,:)],numel(cmin:intv:cmax)-1);
    cID='Intensity (\circC)';

elseif N==3 %BMHW Duration
    X=bhw_frac;
    Y=bhw_diff_time;
    
    cmin=-2.5;
    cmax=2.5;
    intv=(cmax-cmin)./10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    cID='BWTA - SSTA (\circC)';

end

[l,n]=size(X);

yr=1993;
for k=2:n
    yr(k)=yr(k-1)+1/12;
end

clear C
for s=1:l
    [dummy,cm]=cmap_intv(Y(s,:),cmin,cmax,intv,cm);
    C(s,:,:)=dummy;
end

clf
set(gcf,'color','w','position',[-2290 -52 2154 1257])
for k=1:l
    ax(k)=subplot(9,1,k);
    yyaxis right
    ax1=gca;
    plot([yr(1) yr(end)],[f f],'-.','color',[0.75 0.75 0.75],'linewidth',1.5)
    set(ax1,'YColor','k','ylim',[0 f],'yticklabel',[],'xlim',[yr(1)-0.08 yr(end)+0.08],'xtick',[],'fontsize',28)
    yyaxis left
    plot([yr(1) yr(end)],[f/2 f/2],'-.','color',[0.75 0.75 0.75],'linewidth',1.5)
    hold on
    for j=1:n
        if ~isnan(X(k,j))
            h=bar(yr(j),X(k,j).*f,0.08,'FaceColor',squeeze(C(k,j,:)),'edgecolor','none');
        end
    end
    if N==2
        h=stairs(yr,bhw_frac(k,:).*f,'color','k','Marker','none','LineStyle','-','linewidth',1.5);
    end
    hx=gca;
    if k<l
        set(hx,'YColor','k','ylim',[0 f],'xlim',[yr(1)-0.08 yr(end)+0.08],'xtick',1994:2:2018,'xticklabel',[],'fontsize',28)
    else
        set(hx,'YColor','k','ylim',[0 f],'xlim',[yr(1)-0.08 yr(end)+0.08],'xtick',1994:2:2018,'fontsize',28)
    end
    hx.YAxis(1).MinorTick = 'on';
    hx.YAxis(1).MinorTickValues = f/4:f/2:f/2+f/4;
    hx.YAxis(2).MinorTick = 'on';
    hx.YAxis(2).MinorTickValues = f/4:f/2:f/2+f/4;
    hx.XAxis.MinorTick = 'on';
    hx.XAxis.MinorTickValues = 1993:2:2019;
    box off
    
    if k==5
        colormap(cm);
        caxis([cmin cmax])
        cb=colorbar;
        cb.Limits=[cmin cmax];
        cb.Location='EastOutside';
        cb.Ticks=cmin:2*intv:cmax;
        cb.FontSize=28;
        ylabel(cb,cID)
    end
    disp(k)
end

ts=0.0125;
fs=0;
ud=0.0055;
ud2=0.03;
lr=0;

h1=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h1(1)+lr h1(2)+4*ud+ud2 h1(3)+fs h1(4)+ts]);

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)+lr h1(2)+ud+ud2 h1(3)+fs h1(4)+ts]);

h2=get(ax(3),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(3),'position',[h2(1)+lr h2(2)-2*ud+ud2 h2(3)+fs h2(4)+ts]);

h2=get(ax(4),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(4),'position',[h2(1)+lr h2(2)-5*ud+ud2 h2(3)+fs h2(4)+ts]);

h1=get(ax(5),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(5),'position',[h1(1)+lr h1(2)-8*ud+ud2 h2(3)+fs h1(4)+ts]);

h1=get(ax(6),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(6),'position',[h1(1)+lr h1(2)-11*ud+ud2 h1(3)+fs h1(4)+ts]);

h1=get(ax(7),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(7),'position',[h1(1)+lr h1(2)-14*ud+ud2 h1(3)+fs h1(4)+ts]);

h1=get(ax(8),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(8),'position',[h1(1)+lr h1(2)-17*ud+ud2 h1(3)+fs h1(4)+ts]);

h1=get(ax(9),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(9),'position',[h1(1)+lr h1(2)-20*ud+ud2 h1(3)+fs h1(4)+ts]);

h1=get(cb,'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(cb,'position',[h1(1)+0.02 h1(2)-0.25 h1(3)+0.01 h1(4)+0.5]);

if f==100
    text(ax(5),-0.075,0.5,'% of LME Area','Rotation',90,'fontsize',40,'units','normalized','horizontalalignment','center','color','k');
elseif f==1
    text(ax(5),-0.075,0.5,'Fraction of LME Area','Rotation',90,'fontsize',40,'units','normalized','horizontalalignment','center','color','k');
end

if N==2
    left=0.01;
    up=0.83;
    for j=1:9
        text(ax(j),left,up,[lme_ID{j} ' (' num2str(big_shw(j)) ',' num2str(big_bhw(j)) ')'],'fontsize',25,'units','normalized','horizontalalignment','left','color','k');
        %     text(ax(j),left,up,lme_ID{j},'fontsize',23,'units','normalized','horizontalalignment','left','color','k');
    end
end

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
if f==100
    left=-0.04;
elseif f==1
    left=-0.03;
end
up=1.04;
ax_ind=[1 3 4 5 6];
for j=1:9
    text(ax(j),left,up,ind(j),'fontsize',23,'units','normalized','horizontalalignment','center','color','k');
end

% print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/bhw_paper_revised/bhw_figures/Fig8.png','-dpng','-r600');

end

