function the_value = nc_global ()
% NC_GLOBAL:  returns enumerated constant NC_GLOBAL in netcdf.h
%
% USAGE:  the_value = nc_global;

the_value = -1;
return 
