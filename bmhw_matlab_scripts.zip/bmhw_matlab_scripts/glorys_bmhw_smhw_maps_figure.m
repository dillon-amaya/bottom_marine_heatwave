function [ax] = glorys_bmhw_smhw_maps_figure(bhw,shw,bathy_lme,N)

lme_ID={'East Bering Sea'; 'Gulf of Alaska'; 'California Current'; 'Gulf of California';...
    'Gulf of Mexico'; 'Southeast US (SEUS)'; 'Northeast US (NEUS)'; 'Scotian';...
    'Labrador'};

if N==1 %Bathymetry
    X=bathy_lme;
    name='bathy';
    yID='Bottom depth (m)';
    cmin=0;
    cmax=400;
    intv=25;
    cm=flip(haxby(numel(cmin:intv:cmax)-1));
    cm(1,:)=cm(2,:)+[0 0.1 0.1];

elseif N==2 %BMHW Intensity
    X=bhw;
    name='int_avg';
    yID='BMHW average intensity (\circC)';
    cmin=0;
    cmax=5;
    intv=(cmax-cmin)./10;
    yl=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    pu=brewermap(numel(cmin:intv:cmax)-1,'Purples');
    cm=customcolormap([0 0.5 1],[pu(end,:); default_colors('or'); yl(2,:)],numel(cmin:intv:cmax)-1);

elseif N==3 %BMHW Duration
    X=bhw;
    name='dur_avg';
    yID='BMHW average duration (months)';
    cmin=1;
    cmax=4;
    intv=0.25;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    
elseif N==4 %BTA decorrelation timescale
    X=bhw;
    name='decorr';
    yID='BWTA decorrelation timescale (days)';
    cmin=0;
    cmax=300;
    intv=15;
    cm=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    cm(1,:)=[0 0 1];
    
elseif N==5 %SMHW Intensity
    X=shw;
    name='int_avg';
    yID='SMHW average intensity (\circC)';
    cmin=0;
    cmax=5;
    intv=(cmax-cmin)./10;
    yl=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    pu=brewermap(numel(cmin:intv:cmax)-1,'Purples');
    cm=customcolormap([0 0.5 1],[pu(end,:); default_colors('or'); yl(2,:)],numel(cmin:intv:cmax)-1);
    
elseif N==6 %SMHW Duration
    X=shw;
    name='dur_avg';
    yID='SMHW average duration (months)';
    cmin=1;
    cmax=4;
    intv=0.25;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    
elseif N==7 %SSTA decorrelation timescale
    X=shw;
    name='decorr';
    yID='SSTA decorrelation timescale (days)';
    cmin=0;
    cmax=300;
    intv=15;
    cm=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    cm(1,:)=[0 0 1];
    
elseif N==8 %BMHW & SMHW synchrony
    X=shw;
    name='sync';
    yID='BMHW & SMHW synchrony';
    
    cmin=0;
    cmax=1;
    intv=(cmax-cmin)./10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'BuPu');
    
elseif N==9 %MLD/Bathy ratio
    X=shw;
    name='sync_mld';
    yID='MLD/Bathy';
    
    cmin=0;
    cmax=1;
    intv=(cmax-cmin)./10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'BuPu');
    
elseif N==10 %BMHW - SMHW, intensity
    X=shw;
    Y=bhw;
    
    name='int_avg';
    yID='BMHW - SMHW average intensity (\circC)';
    cmin=-2.5;
    cmax=-cmin;
    intv=(cmax-cmin)./10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    
elseif N==11 %BMHW - SMHW, duration
    X=shw;
    Y=bhw;
    
    name='dur_avg';
    yID='BMHW - SMHW average duration (months)';
    cmin=-2.5;
    cmax=-cmin;
    intv=(cmax-cmin)./10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    
elseif N==12 %BMHW - SMHW, decorrelation timescale
    X=shw;
    Y=bhw;
    
    name='decorr';
    yID='BWTA - SSTA decorrelation timescale (days)';
    cmin=-100;
    cmax=-cmin;
    intv=10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
    
end

clf
set(gcf,'position',[-1830 -52 1381 1257],'color','w')
clear ax
for k=1:numel(bhw)
    if N<10
        map=X(k).(name);
    else
        map=Y(k).(name)-X(k).(name);
    end
    map(map<cmin)=cmin+intv;
    map(map>cmax)=cmax-intv;

    latm=bathy_lme(k).lat;
    lonm=-(bathy_lme(k).lon-360);
    lsmask=bathy_lme(k).lsmask;
    lmemask=bathy_lme(k).lme; lmemask(isnan(lmemask))=0;
    
    lsmask2=double(lsmask);
    lsmask2(lsmask2==0)=nan;
    lsmask2(lsmask2==1)=cmin-intv;
    
    ax(k)=subplot(3,3,k);
    h=pcolor(lonm,latm,map);
    set(h,'EdgeColor','none')
    caxis([cmin-intv cmax+intv])
    colormap([[0.925 0.925 0.925]; cm;[0.925 0.925 0.925]])
    hold on
    contour(lonm,latm,lsmask,[0.5 0.5]','color',[0.66 0.66 0.66],'linewidth',1)
    contour(lonm,latm,lmemask,[0.5 0.5]','color','k','linewidth',1)
    contourf(lonm,latm,lsmask2,[cmin-intv cmin-intv],'k','linewidth',1);
    hold off
    set(gca,'xdir','reverse','fontsize',23);
    h=get(gca);
    xticks=h.XTick;
    yticks=h.YTick;
    
    for j=1:numel(xticks)
        xticklabels{j}=[num2str(xticks(j)) '\circW'];
    end
    
    for j=1:numel(yticks)
        yticklabels{j}=[num2str(yticks(j)) '\circN'];
    end
    set(gca,'xticklabel',xticklabels,'yticklabel',yticklabels);
    if k==8
        cb=colorbar;
        cb.Limits=[cmin cmax];
        cb.Location='SouthOutside';
        cb.Ticks=cmin:2*intv:cmax;
        cb.FontSize=23;
        ylabel(cb,yID)
    end
end

left=0.5;
up=1.05;
for j=1:9
    text(ax(j),left,up,lme_ID{j},'fontsize',25,'units','normalized','horizontalalignment','center','color','k');
end

ts=0;
fs=0;
ud=0.02;
lr=0;

h1=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(3),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(3),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(4),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(4),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(5),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(5),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(6),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(6) ,'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(7),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(7),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h2=get(ax(8),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(8),'position',[h2(1)+lr h1(2)+ud h2(3)+fs h1(4)+ts]);

h1=get(ax(9),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(9),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(cb,'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(cb,'position',[h1(1)-0.125 h1(2)-0.0075 h1(3)+0.25 h1(4)+0.0025]);

% h1=get(l,'Position'); %+/- h=[right/left up/down fat/skinny tall/short
% set(l,'Position',[h1(1)+0.1 h1(2) h1(3) h1(4)])

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
left=-0.07;
up=1.1;
for j=1:9
    text(ax(j),left,up,ind(j),'fontsize',23,'units','normalized','horizontalalignment','center','color','k');
end

end

