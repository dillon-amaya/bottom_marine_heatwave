clc; clear; close all;

%Change the pathID variables to point to the GLORYS data on whatever system you're working with.
pathID='/Users/damaya/Desktop/data/reanalysis/GLORYS/monthly/';
pathID2='/Users/damaya/Desktop/data/reanalysis/GLORYS/statics/';
pathID3='/Users/damaya/Desktop/projects/bottom_heatwave/';

path(path,[pathID3 'bmhw_matlab_scripts/']);
path(path,[pathID3 'bmhw_matlab_scripts/snctools']);

%This is my preferred font for figures, feel free to delete
set(0,'DefaultTextFontname', 'CMU Sans Serif')
set(0,'DefaultAxesFontName', 'CMU Sans Serif')

%%
%Section A - Reading in coordinate variables and LME masks

%This code calculates average intensity, duration, spatial extent, and synchrony for
%BMHWs and SMHWs in each LME. All main text Figures and most of the
%Supplementary Information Figures are then made at the end of this script
%using series of functions. User input decides which figure to make. User
%also decides whether to process detrended or raw (e.g., not detrended) by
%changing the parameter "M" in the section titled "Decide whether or not to
%removing warming trend". 

%Data required to run this script includes: GLORYS monthly mean bottomT,
%sst, and mld from 1993-2019. Available at: https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_PHY_001_030/description
%Other processed data (e.g., decorrelation maps, lme masks, etc) are provided in our github repository https://github.com/dillon-amaya/bottom_marine_heatwave

%Change the pathID variables to point to the GLORYS data on whatever system you're working with.

%Reading in bathymetry and lat/lon arrays
lat=nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'latitude');
lat2=flip(nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'latitude'));
lon=nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'longitude');

[time,time2]=time_array(1993,2019,0);

%LME masks on GLORYS grid, created using shape files from https://www.sciencebase.gov/catalog/item/55c77722e4b08400b1fd8244
load('lme_mask2.mat','lme_mask2');
load('lme_lat.mat','lme_lat');
load('lme_lon.mat','lme_lon');

lme_mask=lme_mask2;
clear lme_mask2;
lme_mask(lme_mask==0)=nan;

latmin=dsearchn(lat,15);
latmax=dsearchn(lat,75);
lonmin=dsearchn(lon,170);
lonmax=dsearchn(lon,320);

lat=flip(lat(latmin:latmax));
lon=lon(lonmin:lonmax);

latmin2=dsearchn(lat2,75);
latmax2=dsearchn(lat2,15);

lme_mask=lme_mask(:,latmin2:latmax2,lonmin:lonmax);

%%
%Section B - Reading in GLORYS monthly mean data, calculating monthly anomalies, and organizing by LME

%Reading in GLORYS bottom temperature, sea surface temperature, and MLD data around North America
bathy=flip(nc_varget([pathID2 'GLO-MFC_001_030_mask_bathy.nc'],'deptho',[latmin-1 lonmin-1],[numel(latmin:latmax) numel(lonmin:lonmax)]));
bt_clim=flip(nc_varget([pathID 'bottomT.ltm.1993-2019.nc'],'bottomT',[0 latmin-1 lonmin-1],[-1 numel(latmin:latmax) numel(lonmin:lonmax)]),2);
bt=flip(nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'bottomT',[0 latmin-1 lonmin-1],[-1 numel(latmin:latmax) numel(lonmin:lonmax)]),2);
sst_clim=squeeze(flip(nc_varget([pathID 'sst.ltm.1993-2019.nc'],'thetao',[0 0 latmin-1 lonmin-1],[-1 1 numel(latmin:latmax) numel(lonmin:lonmax)]),3));
sst=squeeze(flip(nc_varget([pathID 'sst.mon.mean.199301-201912.nc'],'thetao',[0 0 latmin-1 lonmin-1],[-1 1 numel(latmin:latmax) numel(lonmin:lonmax)]),3));
mld=flip(nc_varget([pathID 'mlotst.mon.mean.199301-201912.nc'],'mlotst',[0 latmin-1 lonmin-1],[-1 numel(latmin:latmax) numel(lonmin:lonmax)]),2);
mld_clim=flip(nc_varget([pathID 'mlotst.ltm.1993-2019.nc'],'mlotst',[0 latmin-1 lonmin-1],[-1 numel(latmin:latmax) numel(lonmin:lonmax)]),2);
[~,r,q]=size(sst_clim);
n=numel(time);

%Removing seasonal cycle based on 1993-2019 climatology
bta=bt-repmat(bt_clim,[n/12 1 1]); clear bt
ssta=sst-repmat(sst_clim,[n/12 1 1]); clear sst

%Masking bathymetry for different depth intervals
bathyID=[0 50 100 150 200 250 300 350 400]; g=numel(bathyID);
for k=1:numel(bathyID)
    if k==numel(bathyID)
        mask_bathy(k,:,:)=double(bathy<bathyID(k));
    else
        mask_bathy(k,:,:)=double(bathy>bathyID(k)&bathy<=bathyID(k+1));
    end
end
mask_bathy(mask_bathy==0)=nan;

mask=double(isnan(bathy));

%Masking data at depths deeper than 400m
bta_mask=bta.*repmat(mask_bathy(g,:,:),[n 1 1]); 
ssta_mask=ssta.*repmat(mask_bathy(g,:,:),[n 1 1]); 
mld_mask=mld.*repmat(mask_bathy(g,:,:),[n 1 1]); 

%Decorrelation timescale, calculated separately based on DelSole (2001). Uses linearly detrended daily mean.
load('bta_daily_decorr_timescale_lme.mat','bta_lme');
bta_decorr=bta_lme;
load('ssta_daily_decorr_timescale_lme.mat','ssta_lme');
ssta_decorr=ssta_lme;

%Looping through and isolating each LME as separate maps
clear bta_lme ssta_lme mld_lme bathy_lme 
for k=1:size(lme_mask,1)
    x=lme_lon(k).lme;
    x(x<0)=x(x<0)+360;
    y=lme_lat(k).lme;
    
    latmin=min(y);
    latmax=max(y);
    lonmin=min(x);
    lonmax=max(x);
    
    latmin2=dsearchn(lat,latmax);
    latmax2=dsearchn(lat,latmin);
    lonmin2=dsearchn(lon,lonmin);
    lonmax2=dsearchn(lon,lonmax);
    
    bta_lme(k).lme=bta_mask(:,latmin2:latmax2,lonmin2:lonmax2)...
        .*permute(repmat(squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2)),[1 1 n]),[3 1 2]);
    
    ssta_lme(k).lme=ssta_mask(:,latmin2:latmax2,lonmin2:lonmax2)...
        .*permute(repmat(squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2)),[1 1 n]),[3 1 2]);
    
    mld_lme(k).bratio=(mld_mask(:,latmin2:latmax2,lonmin2:lonmax2)./permute(repmat(bathy(latmin2:latmax2,lonmin2:lonmax2),[1 1 n]),[3 1 2]))...
        .*permute(repmat(squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2)),[1 1 n]),[3 1 2]);
    
    bathy_lme(k).bathy=bathy(latmin2:latmax2,lonmin2:lonmax2).*squeeze(mask_bathy(end,latmin2:latmax2,lonmin2:lonmax2))...
        .*squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2));
    bathy_lme(k).lme=squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2));
    bathy_lme(k).lsmask=isnan(bathy(latmin2:latmax2,lonmin2:lonmax2));
    bathy_lme(k).zmask=squeeze(mask_bathy(:,latmin2:latmax2,lonmin2:lonmax2));
    bathy_lme(k).lat=lat(latmin2:latmax2);
    bathy_lme(k).lon=lon(lonmin2:lonmax2);
   
    disp(k)
end

l=numel(bta_lme);
%%
%Section C - Decide whether or not to removing warming trend

M=1; %M=0, no detrending
     %M=1 removes 1st order polynomial
     %M=2 removes 2nd order polynomial
     %M=3 removes 3rd order polynomial

for s=1:l
    y=bta_lme(s).lme;
    w=ssta_lme(s).lme;
    [n,r2,q2]=size(y);
    
    x=(1:n)';
    
    clear bta_det ssta_det
    for k=1:r2
        for j=1:q2 
            if M==0 %Do not detrend
                yy=zeros(n,1);
                ww=zeros(n,1);
            else
                a=polyfit(x,y(:,k,j),M);
                yy=polyval(a,x);
                
                a=polyfit(x,w(:,k,j),M);
                ww=polyval(a,x);
            end
            
            bta_det(:,k,j)=y(:,k,j)-yy;
            ssta_det(:,k,j)=w(:,k,j)-ww;
        end
    end
    bta_lme(s).lme_new=bta_det;
    ssta_lme(s).lme_new=ssta_det;
    disp(s)
end

%%
%Section D - Calculate seasonally evolving 90th percentile

%Bottom temperature 90th percentile for each month and at each grid cell
%Uses a 3-month window to get a more robust distribution
clear bta_90 z
for k=1:l
    x=bta_lme(k).lme_new;
    [n,r2,q2]=size(x);
    
    x_mon=reshape(x,12,n/12,r2,q2);
    for m=1:12
        if m==1
            x_seas=nan(3*(n-12)/12,r2,q2);
            x_seas(1:3:end,:,:)=x_mon(12,1:end-1,:,:);
            x_seas(2:3:end,:,:)=x_mon(1,1:end-1,:,:);
            x_seas(3:3:end,:,:)=x_mon(2,2:end,:,:);
        elseif m==12
            x_seas=nan(3*(n-12)/12,r2,q2);
            x_seas(1:3:end,:,:)=x_mon(11,1:end-1,:,:);
            x_seas(2:3:end,:,:)=x_mon(12,2:end,:,:);
            x_seas(3:3:end,:,:)=x_mon(1,2:end,:,:);
        else
            x_seas=reshape(x_mon(m-1:m+1,:,:,:),3*n/12,r2,q2);
        end
        z(m,:,:)=prctile(x_seas,90);
    end
    bta_90(k).lme=z; clear z
    disp(k)
end

%Sea surface temperature 90th percentile for each month and at each grid cell
clear ssta_90 z
for k=1:l
    x=ssta_lme(k).lme_new;
    [n,r2,q2]=size(x);
    
    x_mon=reshape(x,12,n/12,r2,q2);
    for m=1:12
        if m==1
            x_seas=nan(3*(n-12)/12,r2,q2);
            x_seas(1:3:end,:,:)=x_mon(12,1:end-1,:,:);
            x_seas(2:3:end,:,:)=x_mon(1,1:end-1,:,:);
            x_seas(3:3:end,:,:)=x_mon(2,2:end,:,:);
        elseif m==12
            x_seas=nan(3*(n-12)/12,r2,q2);
            x_seas(1:3:end,:,:)=x_mon(11,1:end-1,:,:);
            x_seas(2:3:end,:,:)=x_mon(12,2:end,:,:);
            x_seas(3:3:end,:,:)=x_mon(1,2:end,:,:);
        else
            x_seas=reshape(x_mon(m-1:m+1,:,:,:),3*n/12,r2,q2);
        end
        z(m,:,:)=prctile(x_seas,90);
    end
    ssta_90(k).lme=z; clear z
    disp(k)
end
%%
%Section E - Calculate average BMHW/SMHW intensity and duration for months above 90th percentile for each grid cell in each LME

%BMHW
clear bhw
for s=1:l
    z=bta_lme(s).lme_new;
    p=bta_90(s).lme;
    [n,r2,q2]=size(z);
    
    z_heat=nan(n,r2,q2);
    for m=1:12
        z_heat2=z(m:12:end,:,:)>=p(m,:,:);
        z_heat(m:12:end,:,:)=z(m:12:end,:,:).*z_heat2;
    end
    
    z_heat(z_heat==0)=nan; %Bottom marine heatwaves

    bhw(s).int_avg=squeeze(nanmean(z_heat)); %Average intensity across all events
    
    for k=1:r2
        for j=1:q2
            if sum(isnan(z_heat(:,k,j)))==n
                bhw(s).dur_avg(k,j)=nan;
            else
                x=~isnan(squeeze(z_heat(:,k,j))); %Month that each event starts
                y = diff([false,x',false]);
                bhw(s).dur_avg(k,j) = mean(find(y<0)-find(y>0)); %Average duration across all events
            end
        end
    end
    
    bhw(s).decorr=bta_decorr(s).decorr; %Placing decorrelation maps into same structure
    
    disp(s)
end

%SMHW
clear shw
for s=1:l
    z=ssta_lme(s).lme_new;
    p=ssta_90(s).lme;
    [n,r2,q2]=size(z);
    
    z_heat=nan(n,r2,q2);
    for m=1:12
        z_heat2=z(m:12:end,:,:)>=p(m,:,:);
        z_heat(m:12:end,:,:)=z(m:12:end,:,:).*z_heat2;
    end
    
    z_heat(z_heat==0)=nan; %urface marine heatwaves

    shw(s).int_avg=squeeze(nanmean(z_heat)); %Average intensity across all events
    
    for k=1:r2
        for j=1:q2
            if sum(isnan(z_heat(:,k,j)))==n
                shw(s).dur_avg(k,j)=nan;
            else
                x=~isnan(squeeze(z_heat(:,k,j))); %Month that each event starts
                y = diff([false,x',false]);
                shw(s).dur_avg(k,j) = mean(find(y<0)-find(y>0)); %Average duration across all events
            end
        end
    end
    
    shw(s).decorr=ssta_decorr(s).decorr; %Placing decorrelation maps into same structur
    
    disp(s)
end
%%
%Section F - Calculating how often SMHW/BMHW events co-occur (i.e., synchrony) in each LME

for s=1:l
    z=ssta_lme(s).lme_new;
    p=ssta_90(s).lme;
    [n,r2,q2]=size(z);
    
    z_heat=nan(n,r2,q2);
    for m=1:12
        z_heat2=z(m:12:end,:,:)>=p(m,:,:);
        z_heat(m:12:end,:,:)=z(m:12:end,:,:).*z_heat2;
    end
    z_heat(z_heat==0)=nan; %Surface marine heatwaves
    
    x=bta_lme(s).lme_new;
    p=bta_90(s).lme;
    [n,r2,q2]=size(x);
    
    x_heat=nan(n,r2,q2);
    for m=1:12
        x_heat2=x(m:12:end,:,:)>=p(m,:,:);
        x_heat(m:12:end,:,:)=x(m:12:end,:,:).*x_heat2;
    end
    x_heat(x_heat==0)=nan; %Bottom marine heatwaves
    
    xn=squeeze(sum(~isnan(x_heat))); %Total number of BMHW events at each grid cell for a given season over the entire record 

    %Finding where SMHW and BMHW events happen at same time and at same location
    sync=~isnan(z_heat)+~isnan(x_heat);
    sync_mask=double(sync==2);
    sync_mask(sync_mask==0)=nan;
    
    w=mld_lme(s).bratio.*sync_mask; %Masking MLD/Bathymetry ratio when BMHW/SMHW are in sync
    w(w>1)=1; %Small number of grid cells with MLD/Bathy > 1, setting = 1 since MLD shouldn't be below the ocean bottom.
    
    shw(s).sync=squeeze(sum(sync==2))./xn; %Adding up co-occuring events, normalizing by total number of BMHW events that occured
    shw(s).sync(isnan(squeeze(z(1,:,:))))=nan;
    shw(s).sync_mld=squeeze(nanmean(w)); %Average MLD/Bathy when BMHW/SMHW are in sync
    
    bhw(s).time=x_heat; %BWTA at grid cells experiencing BMHW conditions as a function time and space
    shw(s).time=z_heat; %SSTA at grid cells experiencing SMHW conditions as a function time and space

    disp(s)
end
%%
%Section G - Calculating area-average BMHW/SMHW intensity and duration across all grid cells in given depth range

%BMHW
clear I_bhw D_bhw g_lme
for k=1:l
    x=bhw(k).int_avg;
    y=bhw(k).dur_avg;
    
    map=bathy_lme(k).zmask;
    latm=bathy_lme(k).lat;
    lonm=bathy_lme(k).lon;
    
    [LON,LAT]=meshgrid(lonm,latm);
    for j=1:g
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        x_mask=x.*squeeze(map(j,:,:));
        y_mask=y.*squeeze(map(j,:,:));
        weight=weight.*~isnan(x_mask);
        weight(weight==0)=nan;
        
        xS=x_mask(:); xS(isnan(xS))=[];
        
        I_bhw(k,j)=nansum(nansum(x_mask.*weight))./nansum(nansum(weight)); %Average BMHW intensity for a given depth range
        D_bhw(k,j)=nansum(nansum(y_mask.*weight))./nansum(nansum(weight)); %Average BMHW duration for a given depth range
        g_lme(k,j)=numel(xS); %Number of grid cells in a given depth range for a given LME
    end
    disp(k)
end

%SMHW
clear I_shw D_shw
for k=1:l
    x=shw(k).int_avg;
    y=shw(k).dur_avg;
    
    map=bathy_lme(k).zmask;
    latm=bathy_lme(k).lat;
    lonm=bathy_lme(k).lon;
    
    [LON,LAT]=meshgrid(lonm,latm);
    for j=1:g
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        x_mask=x.*squeeze(map(j,:,:));
        y_mask=y.*squeeze(map(j,:,:));
        weight=weight.*~isnan(x_mask);
        weight(weight==0)=nan;
        
        xS=x_mask(:); xS(isnan(xS))=[];
        
        I_shw(k,j)=nansum(nansum(x_mask.*weight))./nansum(nansum(weight)); %Average SMHW intensity for a given depth range
        D_shw(k,j)=nansum(nansum(y_mask.*weight))./nansum(nansum(weight)); %Average SMHW duration for a given depth range
    end
    disp(k)
end

%BMHW - SMHW
clear I_diff D_diff
for k=1:l
    x=bhw(k).int_avg;
    y=shw(k).int_avg;
    z=x-y;
    
    x2=bhw(k).dur_avg;
    y2=shw(k).dur_avg;
    z2=x2-y2;
    
    map=bathy_lme(k).zmask;
    latm=bathy_lme(k).lat;
    lonm=bathy_lme(k).lon;
    
    [LON,LAT]=meshgrid(lonm,latm);
    for j=1:g
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        z_mask=z.*squeeze(map(j,:,:));
        weight=weight.*~isnan(z_mask);
        weight(weight==0)=nan;
        
        I_diff(k,j)=nansum(nansum(z_mask.*weight))./nansum(nansum(weight));
        
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        z2_mask=z2.*squeeze(map(j,:,:));
        weight=weight.*~isnan(z2_mask);
        weight(weight==0)=nan;
        
        D_diff(k,j)=nansum(nansum(z2_mask.*weight))./nansum(nansum(weight));
    end
    disp(k)
end

%Restructuring for plotting
I_avg(1,:,:)=I_bhw;
I_avg(2,:,:)=I_shw;
I_avg(3,:,:)=I_diff;

D_avg(1,:,:)=D_bhw;
D_avg(2,:,:)=D_shw;
D_avg(3,:,:)=D_diff;
%%
%Section H - Calculating fraction of LME's area that is in BMHW/SMHW conditions as a function of time

%BMHW
clear bhw_frac
for s=1:l
    x=squeeze(bhw(s).time);
    x=~isnan(x);
    y=nansum(x(:,:),2);
    
    bhw_frac(s,:)=y./g_lme(s,end);
    disp(s)
end
bhw_frac(bhw_frac==0)=nan;

%SMHW
clear shw_frac
for s=1:l
    x=squeeze(shw(s).time);
    x=~isnan(x);
    y=nansum(x(:,:),2);
    
    shw_frac(s,:)=y./g_lme(s,end);
    disp(s)
end
shw_frac(shw_frac==0)=nan;
%%
%Section I - Calculating area-average BWTA/SSTA in grid cells experiencing BMHW conditions as a function of time and LME

%BMHW
clear bhw_int_time bhw_diff_time
for s=1:l
    x=bhw(s).time; %BMHW mask as a function of time, >400m
    x=double(~isnan(x));
    x_bta=bta_lme(s).lme_new;          
    y_ssta=ssta_lme(s).lme_new;         
    latm=bathy_lme(s).lat;
    lonm=bathy_lme(s).lon;
    [LON,LAT]=meshgrid(lonm,latm);
    
    for k=1:n
        x_mask=squeeze(x(k,:,:)); 
        x_mask(x_mask==0)=nan;
        
        x_heat=squeeze(x_bta(k,:,:)).*x_mask; 
        y_heat=squeeze(y_ssta(k,:,:)).*x_mask; 
        
        weight=cosd(LAT.*x_mask);
        bhw_int_time(s,k)=nansum(nansum(x_heat.*weight))./nansum(nansum(weight));
        shw_int=nansum(nansum(y_heat.*weight))./nansum(nansum(weight));
        bhw_diff_time(s,k)=bhw_int_time(s,k)-shw_int;
    end
    disp(s)
end

%SMHW
clear shw_int_time
for s=1:l
    x=shw(s).time; %SMHW mask as a function of time, >400m
    x=double(~isnan(x));

    x_ssta=ssta_lme(s).lme_new;            %Unmasked BTA data for each LME, >400m
    latm=bathy_lme(s).lat;
    lonm=bathy_lme(s).lon;
    [LON,LAT]=meshgrid(lonm,latm);
    
    for k=1:n
        x_mask=squeeze(x(k,:,:)); %BHW mask for given time step, >400m
        x_mask(x_mask==0)=nan;
        
        x_heat=squeeze(x_ssta(k,:,:)).*x_mask; %BTA values at BHW grid cells, >400m
        
        weight=cosd(LAT.*x_mask);
        shw_int_time(s,k)=nansum(nansum(x_heat.*weight))./nansum(nansum(weight));
    end
    disp(s)
end

%%
%Section J - Creating figures

%Figures 1-2,4,6-7,9,S3,S5-S7,S10
%-------------------------------------------------------------------------%
%Maps of different BMHW and/or SMHW characterstics in each LME

N=1;  %N=1 Bathymetry
      %N=2 BMHW average intensity
      %N=3 BMHW average duration
      %N=4 BWTA decorrelation timescale
      %N=5 SMHW average intensity
      %N=6 SMHW average duration
      %N=7 SMHW decorrelation timescale
      %N=8 BMHW & SMHW synchrony
      %N=9 MLD/Bathy ratio
      %N=10 BMHW - SMHW average intensity
      %N=11 BMHW - SMHW average duration
      %N=12 BMHW - SMHW decorrelation timescale
      
[ax] = glorys_bmhw_smhw_maps_figure(bhw,shw,bathy_lme,N);
%%
%Figures 3,10,S1-S2,S4,S9
%-------------------------------------------------------------------------%
%2D histograms between different BMHW and/or SMHW characterstics and the bottom depth or MLD/Bathy ratio of each LME.

N=6;  %N=1 BMHW average intensity versus depth, scatterplot
      %N=2 BMHW average intensity versus depth, histogram
      %N=3 BMHW average duration versus depth, histogram
      %N=4 BMHW - SMHW average intensity versus depth, histogram
      %N=5 BMHW & SMHW synchrony versus depth, histogram
      %N=6 BMHW & SMHW synchrony versus MLD/Bathy ratio, histogram

[ax] = glorys_bmhw_smhw_depth_histogram_figure(bhw,shw,mld_lme,bathy_lme,I_avg,D_avg,g_lme,N);
%%
%Figures 5,8,S8
%-------------------------------------------------------------------------%
%Spatial extent of BMHW/SMHW in each LME as a function of time. Shading bars based on intensity of MHW conditions.

N=1;  %N=1 BMHW spatial extent
      %N=2 SMHW spatial extent, BMHW spatial extent outlined
      %N=3 BMHW spatial extent, BWTA - SSTA intensity

[ax] = glorys_bmhw_smhw_spatial_extent_figure(bhw_frac,bhw_int_time,bhw_diff_time,shw_frac,shw_int_time,1,N);
%%
%Figures S11-S12, Table S2
%-------------------------------------------------------------------------%
%Observational comparisons with GLORYS bottom temperature

run glorys_obs_compare_all_stations.m


