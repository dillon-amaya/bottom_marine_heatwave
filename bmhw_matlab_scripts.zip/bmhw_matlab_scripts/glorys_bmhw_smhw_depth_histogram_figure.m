function [ax] = glorys_bmhw_smhw_depth_histogram_figure(bhw,shw,mld_lme,bathy_lme,I_avg,D_avg,g_lme,N)

lme_ID={'East Bering Sea'; 'Gulf of Alaska'; 'California Current'; 'Gulf of California';...
    'Gulf of Mexico'; 'Southeast US (SEUS)'; 'Northeast US (NEUS)'; 'Scotian';...
    'Labrador'};

g=numel(bhw);

if N==1 %BMHW average intensity versus bottom depth, scatterplot
    X=bathy_lme;
    Y=bhw;
    nx='bathy';
    ny='int_avg';
    
    xID='Bottom Depth (m)';
    yID='BMHW avg. int. (\circC)';
    
    I=squeeze(I_avg(1,:,:));
    D=nan(size(I));
    
elseif N==2 %BMHW average intensity versus bottom depth
    X=bathy_lme;
    Y=bhw;
    nx='bathy';
    ny='int_avg';
    
    xID='Bottom Depth (m)';
    yID='BMHW avg. int. (\circC)';
    
    I=squeeze(I_avg(1,:,:));
    D=nan(size(I));
    
elseif N==3 %BMHW average duration versus bottom depth
    X=bathy_lme;
    Y=bhw;
    nx='bathy';
    ny='dur_avg';
    
    xID='Bottom Depth (m)';
    yID='BMHW avg. dur. (months)';
    
    D=squeeze(D_avg(1,:,:));
    I=nan(size(D));
    
elseif N==4 %BMHW - SMHW average intensity versus bottom depth
    X=bathy_lme;
    Y=bhw;
    Z=shw;
    nx='bathy';
    ny='int_avg';
    
    xID='Bottom Depth (m)';
    yID='BMHW - SMHW avg. int. (\circC)';
    
    I=squeeze(I_avg(3,:,:));
    D=nan(size(I));
    
elseif N==5 %BMHW & SMHW synchrony versus bottom depth
    X=bathy_lme;
    Y=shw;
    nx='bathy';
    ny='sync';
    
    xID='Bottom Depth (m)';
    yID='Synchrony';
    
    I=squeeze(I_avg(3,:,:));
    D=nan(size(I));
    
elseif N==6 %BMHW & SMHW synchrony versus MLD/Bathy
    X=shw;
    Y=shw;
    nx='sync_mld';
    ny='sync';
    
    xID='MLD/Bathy';
    yID='Synchrony';
    
    I=squeeze(I_avg(3,:,:));
    D=nan(size(I));
end

xd=[25 75 125 175 225 275 325 375];

clf
set(gcf,'position',[-1830 -52 1381 1257],'color','w')
cmin=0;
cmax=0.05;
intv=(cmax-cmin)./10;

for k=1:g
    x=X(k).(nx);
    
    if N==4
        y=Y(k).(ny)-Z(k).(ny);
    else
        y=Y(k).(ny);
    end
    
    if N==1
        latm=bathy_lme(3).lat;
        ind=dsearchn(latm,35);
        
        x2=x(ind+1:end,:);
        y2=y(ind+1:end,:);
        
        if k==3
            x=x(1:ind,:);
            x=x(:); %Depth at all grid cells
            x(isnan(x))=[];
            y=y(1:ind,:);
            y=y(:);    %Avg BHW at all grid cells
            y(isnan(y))=[];
            
            x2=x2(:); %Depth at all grid cells
            x2(isnan(x2))=[];
            y2=y2(:);    %Avg BHW at all grid cells
            y2(isnan(y2))=[];
            
            disp(corr(x2,y2,'type','spearman'))
        else
            x=x(:); %Depth at all grid cells
            x(isnan(x))=[];
            y=y(:);    %Avg BHW at all grid cells
            y(isnan(y))=[];
            
            x2=nan(size(x));
            y2=nan(size(y));
        end
        
        ax(k)=subplot(3,3,k);
        if k==3
            h(1)=plot(x,y,'.','markersize',10);
        else
            h(1)=plot(x,y,'.','color',[0.5 0.5 0.5],'markersize',10);
        end
        hold on
        h(2)=plot(x2,y2,'.','markersize',10);
        hold off
        ylabel('BMHW avg. int. (\circC)')
        xlabel('Bottom depth (m)')
        set(gca,'fontsize',18);
        
        if k==3
            [leg, objh] = legend(h,'>35\circN','<35\circN');
            
            objhl = findobj(objh, 'type', 'Line'); % objects of legend of type patch
            set(objhl, 'MarkerSize', 40); %// set marker size as desired
        end
    else
        y(isnan(x))=nan;
        x=x(:); %Depth at all grid cells
        x(isnan(x))=[];
        y=y(:);    %Avg BHW at all grid cells
        y(isnan(y))=[];
        
        ax(k)=subplot(3,3,k);
        cm=brewermap(numel(cmin:intv:cmax)-1,'GnBu');
        h=histogram2(x,y,17,'DisplayStyle','tile','ShowEmptyBins','off','normalization','probability');
                
        if N==6
            h.YBinEdges=linspace(0,1,17);
            h.XBinEdges=linspace(0,1,17);
        else
            h.XBinEdges=0:25:400;
        end
        
        hold on
        if N<5
            plot(xd,I(k,1:g-1),'.','markersize',50,'color',[0.6 0.6 0.6],'linewidth',5);
            plot(xd,D(k,1:g-1),'.','markersize',50,'color',[0.6 0.6 0.6],'linewidth',5);
        end
        hold off
        
        caxis([cmin cmax])
        colormap(cm);
        ylabel(yID)
        xlabel(xID)
        set(gca,'fontsize',20);
        if k==8
            cb=colorbar;
            cb.Limits=[cmin cmax];
            cb.Location='SouthOutside';
            cb.Ticks=cmin:2*intv:cmax;
            ylabel(cb,'Probability')
        end
        
        a=polyfit(x,y,2);
        yy=polyval(a,x);
        
        if N==5
            left=0.62;
            up=0.90;
        elseif N==6
            left=0.675;
            up=0.075;
        else
            left=0.65;
            up=0.925;
        end
        
        if N==5
            text(ax(k),left,up,['R_{1} = ' num2str(round(corr(x,y,'type','spearman'),2))],'fontsize',23,'units','normalized','horizontalalignment','left','color','k');
            text(ax(k),left,up-0.10,['R_{2} = -' num2str(round(corr(y,yy,'type','spearman'),2))],'fontsize',23,'units','normalized','horizontalalignment','left','color','k');
        else
            text(ax(k),left,up,['R = ' num2str(round(corr(x,y,'type','spearman'),2))],'fontsize',23,'units','normalized','horizontalalignment','left','color','k');
        end
    end
end

left=0.5;
up=1.05;
for j=1:9
    text(ax(j),left,up,lme_ID{j},'fontsize',25,'units','normalized','horizontalalignment','center','color','k');
end

ts=0;
fs=0;
ud=0.02;
lr=0;

h1=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(3),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(3),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(4),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(4),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(5),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(5),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(6),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(6),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(7),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(7),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h2=get(ax(8),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(8),'position',[h2(1)+lr h1(2)+ud h2(3)+fs h1(4)+ts]);

h1=get(ax(9),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(9),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

if N~=1
    h1=get(cb,'position'); %+/- h=[right/left up/down fat/skinny tall/short
    set(cb,'position',[h1(1)-0.125 h1(2)-0.0075 h1(3)+0.25 h1(4)+0.0025]);
end

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
left=-0.07;
up=1.1;
ax_ind=[1 3 4 5 6];
for j=1:9
    text(ax(j),left,up,ind(j),'fontsize',20,'units','normalized','horizontalalignment','center','color','k');
end

end

