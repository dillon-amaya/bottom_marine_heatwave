function [time,time2] = time_array(start_year,end_year,flag_day)
%Creates a cell array from start_year to end_year.
%flag_day = 1, produces daily time steps
%flag_day = 0, produces monthly time steps centered on the 15th of each month.

days=[31 28 31 30 31 30 31 31 30 31 30 31];
mon=1:12;
yrs=start_year:end_year;
n=numel(yrs);

if flag_day==1 %Daily time steps
    
    for k=start_year:end_year
        if leapyear(k) %If its a leap year, change February
            days(2)=29;
        else
            days(2)=28;
        end
        if k==start_year
            time=datetime(k,1,1:sum(days))';
        else
            time=[time; datetime(k,1,1:sum(days))'];
        end        
    end
    time2=datestr(time);
    formatIn = 'dd-mmm-yyyy';
    shift=datenum(['01-Jan-' num2str(start_year)]); %Reference units
    time=datenum(time2,formatIn)-shift;
    
elseif flag_day==0  %Monthly time steps
    
    for k=start_year:end_year
        if k==start_year
            time=datetime(k,1:12,15)';
        else
            time=[time; datetime(k,1:12,15)'];
        end        
    end
    time2=datestr(time);
    formatIn = 'dd-mmm-yyyy';
    shift=datenum(['15-Jan-' num2str(start_year)]); %Reference units
    time=datenum(time2,formatIn)-shift;
    
end

end

