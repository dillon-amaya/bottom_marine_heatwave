clc; clear; %close all;
path(path,'/Users/damaya/Desktop/matlab_scripts/');
path(path,'/Users/damaya/Desktop/matlab_scripts/snctools');
%%
set(0,'DefaultTextFontname', 'CMU Sans Serif')
set(0,'DefaultAxesFontName', 'CMU Sans Serif')

%Calculates the decay rate of daily mean bottom temperature and sea surface
%temperature anomalies following the methods of DelSole (2001). Saves the
%output as .mat files for later use.

lat=nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/monthly/bottomT.mon.mean.199301-201912.nc','latitude');
lat2=flip(nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/monthly/bottomT.mon.mean.199301-201912.nc','latitude'));
lon=nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/monthly/bottomT.mon.mean.199301-201912.nc','longitude');

[time,time2]=time_array(1993,2019,1);
ind_lp=find(strcmp(cellstr(time2(:,1:6)),'29-Feb'));
time2(ind_lp,:)=[];

lme_ID={'East Bering Sea'; 'Gulf of Alaska'; 'California Current'; 'Gulf of California';...
    'Gulf of Mexico'; 'Southeast US (SEUS)'; 'Northeast US (NEUS)'; 'Scotian';...
    'Labrador'};
load('/Users/damaya/Desktop/matlab_scripts/bottom_heatwave/lme_mask2.mat','lme_mask2');
load('/Users/damaya/Desktop/matlab_scripts/bottom_heatwave/lme_lat.mat','lme_lat');
load('/Users/damaya/Desktop/matlab_scripts/bottom_heatwave/lme_lon.mat','lme_lon');

lme_mask=lme_mask2;
clear lme_mask2;
lme_mask(lme_mask==0)=nan;

latmin=dsearchn(lat,15);
latmax=dsearchn(lat,75);
lonmin=dsearchn(lon,170);
lonmax=dsearchn(lon,320);

lat=flip(lat(latmin:latmax));
lon=lon(lonmin:lonmax);

latmin2=dsearchn(lat2,75);
latmax2=dsearchn(lat2,15);

lme_mask=lme_mask(:,latmin2:latmax2,lonmin:lonmax);
lme_mask=flip(lme_mask,2);

%Rereading lat/lon in based on daily data
lat=nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bottomT.daily.mean.1993-2019.nam.nc','latitude');
lon=nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bottomT.daily.mean.1993-2019.nam.nc','longitude');

%%
% bathy=flip(nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/statics/GLO-MFC_001_030_mask_bathy.nc','deptho',[latmin-1 lonmin-1],[numel(latmin:latmax) numel(lonmin:lonmax)]));
% bathy=flip(bathy);
% [r,q]=size(bathy);
% n=size(time2,1);
% 
% bathyID=[0 50 100 150 200 250 300 350 400]; g=numel(bathyID);
% for k=1:numel(bathyID)
%     if k==numel(bathyID)
%         mask_bathy(k,:,:)=double(bathy<bathyID(k));
%     else
%         mask_bathy(k,:,:)=double(bathy>bathyID(k)&bathy<=bathyID(k+1));
%     end
% end
% mask_bathy(mask_bathy==0)=nan;
% 
% clear bta_lme ssta_lme bathy_lme %Looping through and isolating each LME as separate maps
% for k=1:numel(lme_ID)
%     disp(lme_ID{k})
% 
%     x=lme_lon(k).lme;
%     x(x<0)=x(x<0)+360;
%     y=lme_lat(k).lme;
%     
%     latmax=min(y);
%     latmin=max(y);
%     lonmin=min(x);
%     lonmax=max(x);
%     
%     latmin2=dsearchn(lat,latmax);
%     latmax2=dsearchn(lat,latmin);
%     lonmin2=dsearchn(lon,lonmin);
%     lonmax2=dsearchn(lon,lonmax);
%     
%     bathy2=flip(bathy(latmin2:latmax2,lonmin2:lonmax2));
%     mask_bathy2=flip(squeeze(mask_bathy(g,latmin2:latmax2,lonmin2:lonmax2)));
%     mask_bathy2=permute(repmat(mask_bathy2,[1 1 n]),[3 1 2]);
%     mask_bathy3=flip(mask_bathy(:,latmin2:latmax2,lonmin2:lonmax2),2);
%     lme_mask2=flip(squeeze(lme_mask(k,latmin2:latmax2,lonmin2:lonmax2)));
%     lme_mask2=permute(repmat(lme_mask2,[1 1 n]),[3 1 2]);
% 
%     disp('Reading in data')
%     bt=flip(nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bottomT.daily.mean.1993-2019.nam.nc','bottomT',[0 latmin2-1 lonmin2-1],[-1 numel(latmin2:latmax2) numel(lonmin2:lonmax2)]),2);
%     sst=squeeze(flip(nc_varget('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/sst.daily.mean.1993-2019.nam.nc','thetao',[0 0 latmin2-1 lonmin2-1],[-1 1 numel(latmin2:latmax2) numel(lonmin2:lonmax2)]),3));
%     
%     bt(ind_lp,:,:)=[];
%     sst(ind_lp,:,:)=[];
%     [n,r,q]=size(bt);
% 
%     bt=bt.*mask_bathy2.*lme_mask2;
%     sst=sst.*mask_bathy2.*lme_mask2;
% 
%     bt_clim=squeeze(mean(reshape(bt,365,n/365,r,q),2));
%     sst_clim=squeeze(mean(reshape(sst,365,n/365,r,q),2));
% 
%     disp('Calculating anomalies')
%     bta=detrend(bt-repmat(bt_clim,[n/365 1 1])); clear bt
%     ssta=detrend(sst-repmat(sst_clim,[n/365 1 1])); clear sst
%     
%     disp('Calculating autocorrelation')
%     bta_decorr=nan(r,q);
%     ssta_decorr=nan(r,q);
%     for j=1:r
%         for i=1:q
%             if ~isnan(bta(1,j,i))
%                 x=squeeze(bta(:,j,i));
%                 [R,~]=xcorr(x,x,365,'coef');
%                 bta_decorr(j,i)=sum(R(:).^2);
%                 
%                 x=squeeze(ssta(:,j,i));
%                 [R,~]=xcorr(x,x,365,'coef');
%                 ssta_decorr(j,i)=sum(R(:).^2);
%             end
%         end
%         disp([num2str(j) ' of ' num2str(r)])
%     end
%    
%     bta_lme(k).decorr=bta_decorr;
%     bta_lme(k).lat=flip(lat(latmin2:latmax2));
%     bta_lme(k).lon=lon(lonmin2:lonmax2);
%     
%     ssta_lme(k).decorr=ssta_decorr;
%     
%     bathy_lme(k).bathy=bathy(latmin2:latmax2,lonmin2:lonmax2).*squeeze(mask_bathy2(1,:,:)).*squeeze(lme_mask2(1,:,:));
%     bathy_lme(k).lme=squeeze(lme_mask2(1,:,:));
%     bathy_lme(k).lsmask=isnan(bathy2);
%     bathy_lme(k).zmask=mask_bathy3;
% end
% l=numel(bta_lme);

% save('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bta_daily_decorr_timescale_lme.mat','bta_lme','-v7.3');
% save('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/ssta_daily_decorr_timescale_lme.mat','ssta_lme','-v7.3');
% save('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bathy_daily_decorr_timescale_lme.mat','bathy_lme','-v7.3');
% 
load('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bta_daily_decorr_timescale_lme.mat','bta_lme');
load('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/ssta_daily_decorr_timescale_lme.mat','ssta_lme');
load('/Users/damaya/Desktop/data/reanalysis/GLORYS/daily/bathy_daily_decorr_timescale_lme.mat','bathy_lme');

l=numel(bta_lme);
g=numel(bathy_lme);
%%
%Average decorrelation across all grid cells in given depth range
clear bta_dc ssta_dc dc_diff
for k=1:l
    x=bta_lme(k).decorr;
    y=ssta_lme(k).decorr;
    z=x-y;
    
    map=bathy_lme(k).zmask;
    latm=bta_lme(k).lat;
    lonm=bta_lme(k).lon;
    
    [LON,LAT]=meshgrid(lonm,latm);
    for j=1:g
        
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        x_mask=x.*squeeze(map(j,:,:));
        weight=weight.*~isnan(x_mask);
        weight(weight==0)=nan;
        
        bta_dc(k,j)=nansum(nansum(x_mask.*weight))./nansum(nansum(weight));
        
        weight=cosd(LAT.*squeeze(map(j,:,:)));
        y_mask=y.*squeeze(map(j,:,:));
        weight=weight.*~isnan(y_mask);
        weight(weight==0)=nan;
        
        ssta_dc(k,j)=nansum(nansum(y_mask.*weight))./nansum(nansum(weight));

        weight=cosd(LAT.*squeeze(map(j,:,:)));
        z_mask=z.*squeeze(map(j,:,:));
        weight=weight.*~isnan(z_mask);
        weight(weight==0)=nan;
        
        dc_diff(k,j)=nansum(nansum(z_mask.*weight))./nansum(nansum(weight));
    end
    disp(lme_ID{k})
end

%%
%Average intensity difference, bottom minus surface 
N=3;

if N==1
    X=bta_lme;
    name='decorr';
    yID='BWTA decorrelation timescale (days)';
    cmin=0;
    cmax=300;
    intv=15;
    cm=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    cm(1,:)=[0 0 1];
%     cm(2,:)=[1 0 1];

elseif N==2
    X=ssta_lme;
    name='decorr';
    yID='SSTA decorrelation timescale (days)';
    cmin=0;
    cmax=300;
    intv=15;
    cm=brewermap(numel(cmin:intv:cmax)-1,'YlOrRd');
    cm(1,:)=[0 0 1];

elseif N==3
    X=ssta_lme;
    Y=bta_lme;
    
    name='decorr';
    yID='BWTA - SSTA decorrelation timescale (days)';
    cmin=-100;
    cmax=-cmin;
    intv=10;
    cm=brewermap(numel(cmin:intv:cmax)-1,'*RdYlBu');
end
        
clf
set(gcf,'position',[-1830 -52 1381 1257],'color','w')
clear ax
for k=1:l
    if N==3
        map=Y(k).(name)-X(k).(name);
    else
        map=X(k).(name);
    end
    map(map<cmin)=cmin+intv;
    map(map>cmax)=cmax-intv;

    latm=bta_lme(k).lat;
    lonm=-(bta_lme(k).lon-360);
    lsmask=bathy_lme(k).lsmask;
    lmemask=bathy_lme(k).lme; lmemask(isnan(lmemask))=0;
    
    lsmask2=double(lsmask);
    lsmask2(lsmask2==0)=nan;
    lsmask2(lsmask2==1)=cmin-intv;
    
    ax(k)=subplot(3,3,k);
    h=pcolor(lonm,latm,map);
    set(h,'EdgeColor','none')
    caxis([cmin-intv cmax+intv])
    colormap([[0.925 0.925 0.925]; cm;[0.925 0.925 0.925]])
    hold on
    contour(lonm,latm,lsmask,[0.5 0.5]','color',[0.66 0.66 0.66],'linewidth',1)
    contour(lonm,latm,lmemask,[0.5 0.5]','color','k','linewidth',1)
    contourf(lonm,latm,lsmask2,[cmin-intv cmin-intv],'k','linewidth',1);
    hold off
    set(gca,'xdir','reverse','fontsize',23);
    h=get(gca);
    xticks=h.XTick;
    yticks=h.YTick;
    
    for j=1:numel(xticks)
        xticklabels{j}=[num2str(xticks(j)) '\circW'];
    end
    
    for j=1:numel(yticks)
        yticklabels{j}=[num2str(yticks(j)) '\circN'];
    end
    set(gca,'xticklabel',xticklabels,'yticklabel',yticklabels);
    if k==8
        cb=colorbar;
        cb.Limits=[cmin cmax];
        cb.Location='SouthOutside';
        cb.Ticks=cmin:2*intv:cmax;
        cb.FontSize=23;
        ylabel(cb,yID)
    end
end

left=0.5;
up=1.05;
% for j=1:9
%     text(ax(j),left,up,[ind{j} ' ' lme_ID{j}],'fontsize',25,'units','normalized','horizontalalignment','center','color','k');
% end
for j=1:9
    text(ax(j),left,up,lme_ID{j},'fontsize',25,'units','normalized','horizontalalignment','center','color','k');
end

ts=0;
fs=0;
ud=0.02;
lr=0;

h1=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(3),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(3),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(4),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(4),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(5),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(5),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(6),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(6) ,'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(7),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(7),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h2=get(ax(8),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(8),'position',[h2(1)+lr h1(2)+ud h2(3)+fs h1(4)+ts]);

h1=get(ax(9),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(9),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(cb,'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(cb,'position',[h1(1)-0.125 h1(2)-0.0075 h1(3)+0.25 h1(4)+0.0025]);

% h1=get(l,'Position'); %+/- h=[right/left up/down fat/skinny tall/short
% set(l,'Position',[h1(1)+0.1 h1(2) h1(3) h1(4)])

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
left=-0.07;
up=1.1;
for j=1:9
    text(ax(j),left,up,ind(j),'fontsize',23,'units','normalized','horizontalalignment','center','color','k');
end
%
% if N==1
%     print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/bhw_paper_revised/bhw_figures/FigS5.png','-dpng','-r600');
% elseif N==2
%     print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/bhw_paper_revised/bhw_figures/FigS6.png','-dpng','-r600');
% elseif N==3
%     print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/bhw_paper_revised/bhw_figures/FigS7.png','-dpng','-r600');
% end

    

