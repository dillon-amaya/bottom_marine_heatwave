function [C,cm] = cmap_intv(x,cmin,cmax,intv,cm)
%Returns the RGB values in the specified colormap "cm" that correspond with
%the values at each time step in "x". Only works with brewermap!

val=cmin:intv:cmax;

n=numel(x);

C=nan(n,3);
for k=1:numel(val)+1
    if k==numel(val)
        ind=x>val(k);
        C(ind,:)=repmat(cm(end,:),[sum(ind) 1]);
    elseif k==numel(val)+1
        ind=x<=val(1);
        C(ind,:)=repmat(cm(1,:),[sum(ind) 1]);
    else
        ind=x>val(k)&x<=val(k+1);
        C(ind,:)=repmat(cm(k,:),[sum(ind) 1]);
    end
end

end

