function [x_anom]=anom_timeseries(var,yr0,yr1,yr2)
%Calculates anomalies of the variable using climatology for given time interval specified.
%ONLY USE IF THE DATA STARTS IN JANUARY AND ENDS IN DECEMBER!

year0=yr0; %start data 
year1=yr1; %start climatology
year2=yr2; %end climatology

var2=var(((year1-year0)*12)+1:((year2-year0)+1)*12);
n=numel(var);
n2=numel(var2);
x1=reshape(var,[12 n/12]);
x2=reshape(var2,[12 n2/12]);
x_clim=squeeze(nanmean(x2,2));
x_clim_new=reshape(x_clim,[12 1]);
x3=repmat(x_clim_new,[1 n/12]);

x_anom=x1-x3;
x_anom=reshape(x_anom,n,1);

end
