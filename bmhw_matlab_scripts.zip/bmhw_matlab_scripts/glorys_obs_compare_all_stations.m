%Change the pathID variables to point to the GLORYS data on whatever system you're working with.
pathID='/Users/damaya/Desktop/data/reanalysis/GLORYS/monthly/';
pathID2='/Users/damaya/Desktop/data/reanalysis/GLORYS/statics/';
pathID3='/Users/damaya/Desktop/projects/bottom_heatwave/';

path(path,[pathID3 'bmhw_matlab_scripts']);
path(path,[pathID3 'bmhw_matlab_scripts/additional_data_and_functions']);
path(path,[pathID3 'bmhw_matlab_scripts/observational_data']);
path(path,[pathID3 'bmhw_matlab_scripts/snctools']);

%This is my preferred font for figures, feel free to delete
set(0,'DefaultTextFontname', 'CMU Sans Serif')
set(0,'DefaultAxesFontName', 'CMU Sans Serif')

%%
%Comparing GLORYS to all observational stations, next to a map with station locations

lat=nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'latitude');
lat2=flip(nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'latitude'));
lon=nc_varget([pathID 'bottomT.mon.mean.199301-201912.nc'],'longitude');

[time,time2]=time_array(1993,2019,0);

lme_ID={'East Bering Sea'; 'Gulf of Alaska'; 'California Current'; 'Gulf of California';...
    'Gulf of Mexico'; 'Southeast U.S. Continental Shelf'; 'Northeast U.S. Continental Shelf'; 'Scotian Shelf';...
    'Labrador - Newfoundland'};
load('/Users/damaya/Desktop/matlab_scripts/bottom_heatwave/lme_mask2.mat','lme_mask2');

lme_mask=lme_mask2;

latmin=dsearchn(lat,15);
latmax=dsearchn(lat,75);
lonmin=dsearchn(lon,170);
lonmax=dsearchn(lon,320);

lat=flip(lat(latmin:latmax));
lon=lon(lonmin:lonmax);

latmin2=dsearchn(lat2,75);
latmax2=dsearchn(lat2,15);

lme_mask=lme_mask(:,latmin2:latmax2,lonmin:lonmax);

bathy=flip(nc_varget([pathID2 'GLO-MFC_001_030_mask_bathy.nc'],'deptho',[latmin-1 lonmin-1],[numel(latmin:latmax) numel(lonmin:lonmax)]));
%%
%Reading in observation timeseries

load('BS.M5.mon.mean.2005-2018.mat','bt_bs5','bs5x','bs5y','bs5z','time_bs5');
load('BS.M8.mon.mean.2005-2018.mat','bt_bs8','bs8x','bs8y','bs8z','time_bs8');
load('GAK.mon.mean.1998-2018.mat','bt_gak','gakx','gaky','gakz','time_gak');
load('GOM.mon.mean.2004-2018.mat','bt_gom','gomx','gomy','gomz');
load('FS.mon.mean.2001-2019.mat','bt_fs','fsx','fsy','fsz','time_fs');
load('MVCO.mon.mean.2001-2018.mat','bt_mv','mvx','mvy','mvz','time_mv');
load('Newport.1997-2019.T3.mat','bt_new','newx','newy','newz','time_new');
load('PB.int.mon.mean.1993-2018.mat','bt_pb','pbx','pby','pbz');
load('hf.mon.mean.2000-2019.mat','bt_hf','hfx','hfy','hfz','time_hf');
load('Newf.mon.mean.1993-2019.mat','bt_newf','newfx','newfy','time_newf');

%Reading in GLORYS timeseries

load('glorys.BS.M5.mon.mean.2005-2018.mat','btg_bs5','bs5xg','bs5yg','bs5zg','time_bs5g');
load('glorys.BS.M8.mon.mean.2005-2018.mat','btg_bs8','bs8xg','bs8yg','bs8zg','time_bs8g');
load('glorys.GAK.mon.mean.1998-2018.mat','btg_gak','gakxg','gakyg','gakzg','time_gakg');
load('glorys.GOM.mon.mean.2004-2018.mat','btg_gom','gomxg','gomyg','gomzg','time_gomg');
load('glorys.FS.mon.mean.2001-2019.mat','btg_fs','fsxg','fsyg','fszg','time_fsg');
load('glorys.MVCO.mon.mean.2001-2018.mat','btg_mv','mvxg','mvyg','mvzg','time_mvg');
load('glorys.Newport.1997-2019.T3.mat','btg_new','newxg','newyg','newzg','time_newg');
load('glorys.PB.mon.mean.1993-2018.mat','btg_pb','pbxg','pbyg','pbzg','time_pbg');
load('glorys.hf2.mon.mean.2000-2019.mat','btg_hf','hfxg','hfyg','hfzg','time_hfg');
load('glorys.Newf.mon.mean.1993-2019.mat','btg_newf','newfxg','newfyg','newfzg','time_newfg');

obsx=[bs8x bs5x gakx newx gomx fsx mvx pbx hfx newfx];
obsy=[bs8y bs5y gaky newy gomy fsy mvy pby hfy newfy];

obs(1).data=bt_bs8;
obs(2).data=bt_bs5;
obs(3).data=bt_gak;
obs(4).data=bt_new;
obs(5).data=bt_gom;
obs(6).data=bt_fs;
obs(7).data=bt_mv;
obs(8).data=bt_pb;
obs(9).data=bt_hf;
obs(10).data=bt_newf;

obs(1).time=time_bs8g;
obs(2).time=time_bs5g;
obs(3).time=time_gakg;
obs(4).time=time_newg;
obs(5).time=time_gomg;
obs(6).time=time_fsg;
obs(7).time=time_mvg;
obs(8).time=time_pbg;
obs(9).time=time_hfg;
obs(10).time=time_newfg;

glo(1).data=btg_bs8;
glo(2).data=btg_bs5;
glo(3).data=btg_gak;
glo(4).data=btg_new;
glo(5).data=btg_gom;
glo(6).data=btg_fs;
glo(7).data=btg_mv;
glo(8).data=btg_pb;
glo(9).data=btg_hf;
glo(10).data=btg_newf;

%%
%Figure S11 -> Map with data locations
cmin=0;
cmax=400;
intv=25;

map=bathy;
map(map>400)=nan;
map(map<cmin)=cmin+intv;
map(map>cmax)=cmax-intv;

mask=double(isnan(bathy));
mask2=double(mask);
mask2(mask2==0)=nan;
mask2(mask2==1)=cmin-intv;

cm=flip(haxby(numel(cmin:intv:cmax)-1));
cm(1,:)=cm(2,:)+[0 0.1 0.1];

clf
set(gcf,'color','w','position',[-2412 300 2558 811])
ax(1)=subplot(1,2,1);
h=pcolor(lon,lat,map);
set(h,'EdgeColor','none')
caxis([cmin-intv cmax+intv])
colormap([[0.925 0.925 0.925]; cm;[0.925 0.925 0.925]])
hold on
contour(lon,lat,mask,[0.5 0.5]','color',[0.66 0.66 0.66],'linewidth',0.5)
contourf(lon,lat,mask2,[cmin-intv cmin-intv],'k','linewidth',1);
% for k=1:numel(lme_ID)
%     contour(lon,lat,squeeze(lme_mask(k,:,:)),[0.5 0.5]','color','k','linewidth',2)
% end
for k=1:numel(obsx)
    plot(obsx(k),obsy(k),'.k','markersize',50)
end
hold off
yticklabels={'40\circN' '50\circN' '60\circN' '70\circN'};
xticklabels={'180\circ' '165\circW' '150\circW' '135\circW' '120\circW'};
set(gca,'ylim',[40 72],'xlim',[lon(1) 240],'ytick',40:10:70,'xtick',180:15:240,...
    'yticklabel',yticklabels,'xticklabel',xticklabels,'fontsize',20);
cb=colorbar;
cb.Location='SouthOutside';
cb.Limits=[cmin cmax];
cb.Ticks=cmin:2*intv:cmax;
ylabel(cb,'Bathymetry (m)')

ax(2)=subplot(1,2,2);
h=pcolor(lon,lat,map);
set(h,'EdgeColor','none')
caxis([cmin-intv cmax+intv])
colormap([[0.925 0.925 0.925]; cm;[0.925 0.925 0.925]])
hold on
contour(lon,lat,mask,[0.5 0.5]','color',[0.66 0.66 0.66],'linewidth',0.5)
contourf(lon,lat,mask2,[cmin-intv cmin-intv],'k','linewidth',1);
% for k=1:numel(lme_ID)
%     contour(lon,lat,squeeze(lme_mask(k,:,:)),[0.5 0.5]','color','k','linewidth',2)
% end
for k=1:numel(obsx)
    plot(obsx(k),obsy(k),'.k','markersize',50)
end
hold off
yticklabels={'20\circN' '30\circN' '40\circN' '50\circN' '60\circN'};
xticklabels={'130\circW' '100\circW' '70\circW' '40\circW'};
set(gca,'ylim',[18 61],'xlim',[225 320],'ytick',20:10:60,'xtick',230:30:320,...
    'yticklabel',yticklabels,'xticklabel',xticklabels,'fontsize',20);

ts=-0.1;
fs=0.05;
ud=0.1;
lr=0.1;

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)-1.7*lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h2=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h2(1)-lr h1(2)+ud h2(3) h1(4)+ts]);

h1=get(cb,'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(cb,'position',[h1(1)+0.16 h1(2)-0.05 h1(3)+0.05 h1(4)+0.01]);

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
left=-0.02;
up=1.04;
for j=1:2
    text(ax(j),left,up,ind(j),'fontsize',20,'units','normalized','horizontalalignment','center','color','k');
end

text(ax(1),bs8x-1,bs8y+1,'BS-M8','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(1),bs5x-1,bs5y+1,'BS-M5','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(1),gakx+4.5,gaky-1.5,'GAK1','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(1),newx-8,newy+0.1,'Newport Line','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),newx+9,newy+0.1,'Newport Line','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),gomx-6,gomy+1.75,'West End CP','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),fsx+8,fsy+1.5,'Walton Smith','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),mvx-5,mvy+1.5,'MVCO','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),pbx-12,pby+1,'Passamaquoddy Bay','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),hfx+7,hfy-1.5,'Halifax Line','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');
text(ax(2),newfx+6,newfy-1.5,'Station 27','fontsize',25,'horizontalalignment','center','verticalalignment','middle','color','k');

% print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/glorys_bathymetry_obs_locations.png','-dpng','-r600');
%%
%Fig. S12 -> Timeseries comparisons
tID={'Bering Sea (BS-M8)' 'Bering Sea (BS-M5)' 'Gulf of Alaska (GAK1)' 'California Current System (Newport Line)'...
    'Gulf of Mexico (West End CP)' 'Southeast US (Walton Smith)','Northeast US (MVCO)','Northeast US (Passam. Bay)'...
    'Scotian Shelf (Halifax Line)' 'Labrador Shelf (Station 27)'};

inds=[1 3 5 7 9 2 4 6 8 10];

clf
set(gcf,'position',[-2202 -52 1811 1257],'color','w')
for k=1:numel(obsx)
    yr1=str2double(obs(k).time(1,8:end));
    yr2=str2double(obs(k).time(end,8:end));
    
    o=obs(k).data;
    g=glo(k).data;
    
    n=numel(o);
    
    yr=yr1;
    for j=2:n
        yr(j)=yr(j-1)+1/12;
    end
    
    if k==6||k==9
        oa=o;
        ga=g;
    else
                oa=o-repmat(squeeze(nanmean(reshape(o,12,n/12),2)),[n/12 1]);
                ga=anom_timeseries(g,yr1,yr1,yr2);
        
%         oa=detrend(o-repmat(squeeze(nanmean(reshape(o,12,n/12),2)),[n/12 1]),'omitnan');
%         ga=detrend(anom_timeseries(g,yr1,yr1,yr2));
    end
    
    mask=double(~isnan(oa));
    mask(mask==0)=nan;
    
    ga2=ga.*mask; %Masking glorys to have same steps as obs, have to do this or not fair comparison of duration
    
    o90=prctile(oa,90);
    g90=prctile(ga2,90);
    
    indo=oa>o90;
    indg=ga2>g90;
    
    bhwo=oa.*indo;
    bhwg=ga2.*indg;
    
    bhwo(bhwo==0)=nan;
    bhwg(bhwg==0)=nan;
    
    frac(k)=sum((indo+indg)==2)/sum(indo);
    
    x=oa;
    y=ga;
    
    y(isnan(x))=[];
    x(isnan(x))=[];
    
    R=corr(x,y);
    
    if k==6
        c=1;
        for j=2001:2019
            x=find(strcmp(cellstr(time_fsg(:,8:11)),num2str(j)));
            xtick(c)=x(1);
            c=c+1;
        end
        xtick=xtick(1:2:end);
        xticklabel=time_fsg(xtick,8:11);
        yr=1:n;
        yr1=1;
        yr2=n;
    elseif k==9
        c=1;
        for j=2000:2019
            x=find(strcmp(cellstr(time_hfg(:,8:11)),num2str(j)));
            xtick(c)=x(1);
            c=c+1;
        end
        ytick=0:2:10;
        xtick=xtick(1:2:end);
        xticklabel=time_hfg(xtick,8:11);
        yr=1:n;
        yr1=1;
        yr2=n;
    else
        xtick=yr1:2:yr2+1;
        xticklabel=yr1:2:yr2+1;
    end
    
    ax(inds(k))=subplot(5,2,inds(k));
    h(2)=plot(yr,ga,'r','linewidth',3);
    hold on
    h(1)=plot(yr,oa,'k','linewidth',3);
%     if k~=6
%         plot(yr,bhwg,'r.','markersize',40);
%         plot(yr,bhwo,'k.','markersize',40);
%     end
    hold off
    if k==6||k==9
        ylabel('NBT (\circC)')
    else
        ylabel('NBTA (\circC)')
    end
    if k==9
        set(gca,'xlim',[yr1 yr2+1],'xtick',xtick,'xticklabel',xticklabel,'xticklabelrotation',0,'ytick',ytick','fontsize',15)
    else
        set(gca,'xlim',[yr1 yr2+1],'xtick',xtick,'xticklabel',xticklabel,'xticklabelrotation',0,'fontsize',15)
    end
    title([tID{k} ', R(' num2str(round(R,2)) ')'],'fontweight','normal','fontsize',20)
    if k==5
        leg=legend(h,'Observations','GLORYS','location','southoutside','numcolumns',2,'box','off','fontsize',20);
    end
end

ts=0.01;
fs=0;
ud=0.015;
lr=0.03;

h1=get(ax(1),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(1),'position',[h1(1)+lr h1(2)+2*ud h1(3)+fs h1(4)+ts]);

h1=get(ax(2),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(2),'position',[h1(1)-lr h1(2)+2*ud h1(3)+fs h1(4)+ts]);

h1=get(ax(3),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(3),'position',[h1(1)+lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(4),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(4),'position',[h1(1)-lr h1(2)+ud h1(3)+fs h1(4)+ts]);

h1=get(ax(5),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(5),'position',[h1(1)+lr h1(2) h1(3)+fs h1(4)+ts]);

h1=get(ax(6),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(6),'position',[h1(1)-lr h1(2) h1(3)+fs h1(4)+ts]);

h1=get(ax(7),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(7),'position',[h1(1)+lr h1(2)-ud h1(3)+fs h1(4)+ts]);

h1=get(ax(8),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(8),'position',[h1(1)-lr h1(2)-ud h1(3)+fs h1(4)+ts]);

h1=get(ax(9),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(9),'position',[h1(1)+lr h1(2)-2*ud h1(3)+fs h1(4)+ts]);

h1=get(ax(10),'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(ax(10),'position',[h1(1)-lr h1(2)-2*ud h1(3)+fs h1(4)+ts]);

ind={'(a)'; '(b)'; '(c)'; '(d)'; '(e)'; '(f)'; '(g)'; '(h)'; '(i)'; '(j)'; '(k)'; '(l)'};
left=-0.04;
up=1.12;
% left=0.025;
% up=0.925;
for j=1:numel(obsx)
    text(ax(inds(j)),left,up,ind(j),'fontsize',20,'units','normalized','horizontalalignment','center','color','k');
end

h1=get(leg,'position'); %+/- h=[right/left up/down fat/skinny tall/short
set(leg,'position',[h1(1)+0.175 h1(2)-0.01 h1(3) h1(4)]);

% print(gcf,'/Users/damaya/Desktop/projects/bottom_heatwave/glorys_obs_bottom_temp_compare.png','-dpng','-r600');
%%
%Table S2 -> Calculating MHW statistics

c=1;
for k=1:numel(obsx)
    yr1=str2double(obs(k).time(1,8:end));
    yr2=str2double(obs(k).time(end,8:end));
    
    o=obs(k).data;
    g=glo(k).data;
    
    n=numel(o);
    
    if k==6||k==9
        bhwo_int(k)=nan;
        bhwg_int(k)=nan;
        
        bhwo_dur(k)=nan;
        bhwg_dur(k)=nan;
    else
        
        %Uncomment if you want to detrend data before calculating statistics
        %oa=detrend(o-repmat(squeeze(nanmean(reshape(o,12,n/12),2)),[n/12 1]),'omitnan');
        %ga=detrend(anom_timeseries(g,yr1,yr1,yr2));
        
        oa=o-repmat(squeeze(nanmean(reshape(o,12,n/12),2)),[n/12 1]);
        ga=anom_timeseries(g,yr1,yr1,yr2);
        
        mask=double(~isnan(oa));
        mask(mask==0)=nan;
        
        ga=ga.*mask; %Masking glorys to have same steps as obs, have to do this or not fair comparison of duration
        
        o90=prctile(oa,90);
        g90=prctile(ga,90);
        
        indo=oa>o90;
        indg=ga>g90;
        
        bhwo=oa.*indo;
        bhwg=ga.*indg;
        
        bhwo(bhwo==0)=nan;
        bhwg(bhwg==0)=nan;
        
        bhwo_int(k)=nanmean(bhwo);
        bhwg_int(k)=nanmean(bhwg);
        
        x=~isnan(bhwo);
        y = diff([false,x',false]);
        bhwo_dur(k) = mean(find(y<0)-find(y>0)); % length
        
        x=~isnan(bhwg);
        y = diff([false,x',false]);
        bhwg_dur(k) = mean(find(y<0)-find(y>0)); % length
    end
end




